/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { 
  Plus, 
  Trash2, 
  Play, 
  ChevronRight, 
  RotateCcw, 
  Users, 
  User, 
  Shield, 
  Search, 
  Zap, 
  Hand, 
  Flag,
  Info,
  ArrowLeft
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

// Utility for tailwind classes
function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---

type Screen = 'home' | 'players' | 'games' | 'instructions' | 'drawing' | 'result';

interface Game {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  color: string;
  logic: 'single' | 'teams' | 'numbered-teams';
}

interface Player {
  id: string;
  name: string;
  color: string;
  avatar: string;
}

interface Result {
  type: 'single' | 'teams';
  assignments: {
    label?: string;
    players: Player[];
    color?: string;
  }[];
}

// --- Constants ---

const GAMES: Game[] = [
  {
    id: 'pilla-pilla',
    name: 'Pilla pilla',
    icon: <Zap className="w-10 h-10" />,
    description: 'Uno persigue y los demás escapan. ¡Si te tocan, la ligas tú!',
    color: 'bg-brand-secondary',
    logic: 'single'
  },
  {
    id: 'escondite',
    name: 'Escondite',
    icon: <Search className="w-10 h-10" />,
    description: 'Uno cuenta hasta 20 mientras los demás se esconden. ¡A buscar!',
    color: 'bg-indigo-400',
    logic: 'single'
  },
  {
    id: 'policias-ladrones',
    name: 'Policías y ladrones',
    icon: <Shield className="w-10 h-10" />,
    description: 'Dos equipos: unos atrapan y otros intentan no ser pillados.',
    color: 'bg-brand-primary',
    logic: 'teams'
  },
  {
    id: 'panuelo',
    name: 'El pañuelo',
    icon: <Hand className="w-10 h-10" />,
    description: 'Dos equipos enfrentados. Cada uno tiene un número. ¡Corre a por el pañuelo!',
    color: 'bg-rose-400',
    logic: 'numbered-teams'
  },
  {
    id: 'carrera-equipos',
    name: 'Carrera por equipos',
    icon: <Flag className="w-10 h-10" />,
    description: 'Relevos o carreras conjuntas para ver qué equipo llega antes.',
    color: 'bg-emerald-400',
    logic: 'teams'
  }
];

const PLAYER_COLORS = [
  'bg-[#FF6B6B]', 'bg-[#4ECDC4]', 'bg-[#45B7D1]', 'bg-[#FFA07A]', 
  'bg-[#98D8C8]', 'bg-[#F7D794]', 'bg-[#778BEB]', 'bg-[#F8A5C2]',
  'bg-[#63CDDA]', 'bg-[#CF6A87]'
];

const AVATARS = [
  '🦁', '🐯', '🦒', '🦊', '🐼', '🐨', '🐰', '🐹', '🦄', '🐲',
  '🚀', '🛸', '🌈', '🍦', '🍕', '⚽', '🎨', '🎸', '🎮', '🦸'
];

// --- Components ---

export default function App() {
  const [screen, setScreen] = useState<Screen>('home');
  const [players, setPlayers] = useState<Player[]>([]);
  const [playerName, setPlayerName] = useState('');
  const [selectedGame, setSelectedGame] = useState<Game | null>(null);
  const [result, setResult] = useState<Result | null>(null);

  // --- Logic ---

  const addPlayer = () => {
    if (playerName.trim() && players.length < 10) {
      const newPlayer: Player = {
        id: Math.random().toString(36).substr(2, 9),
        name: playerName.trim(),
        color: PLAYER_COLORS[players.length % PLAYER_COLORS.length],
        avatar: AVATARS[Math.floor(Math.random() * AVATARS.length)]
      };
      setPlayers([...players, newPlayer]);
      setPlayerName('');
    }
  };

  const changeAvatar = (id: string) => {
    setPlayers(players.map(p => {
      if (p.id === id) {
        const currentIndex = AVATARS.indexOf(p.avatar);
        const nextIndex = (currentIndex + 1) % AVATARS.length;
        return { ...p, avatar: AVATARS[nextIndex] };
      }
      return p;
    }));
    playPopSound();
  };

  const removePlayer = (id: string) => {
    setPlayers(players.filter(p => p.id !== id));
  };

  const playPopSound = () => {
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2571/2571-preview.mp3');
    audio.volume = 0.4;
    audio.play().catch(() => {});
  };

  const startDrawing = () => {
    setScreen('drawing');
    
    // Play a subtle "magic" sound
    const audio = new Audio('https://assets.mixkit.co/active_storage/sfx/2019/2019-preview.mp3');
    audio.volume = 0.3;
    audio.play().catch(() => {}); // Ignore errors if browser blocks autoplay

    setTimeout(() => {
      performDraw();
      setScreen('result');
    }, 3000); // Slightly longer for better effect
  };

  const performDraw = () => {
    if (!selectedGame || players.length === 0) return;

    const shuffled = [...players].sort(() => Math.random() - 0.5);

    if (selectedGame.logic === 'single') {
      const chosen = shuffled[0];
      const others = shuffled.slice(1);
      setResult({
        type: 'single',
        assignments: [
          { label: '¡La liga!', players: [chosen], color: 'bg-brand-accent' },
          { label: 'Escapan', players: others, color: 'bg-slate-100' }
        ]
      });
    } else if (selectedGame.logic === 'teams' || selectedGame.logic === 'numbered-teams') {
      const mid = Math.ceil(shuffled.length / 2);
      const teamA = shuffled.slice(0, mid);
      const teamB = shuffled.slice(mid);
      
      setResult({
        type: 'teams',
        assignments: [
          { label: 'Equipo Azul', players: teamA, color: 'bg-[#4E95FF]' },
          { label: 'Equipo Rosa', players: teamB, color: 'bg-[#FF5C8D]' }
        ]
      });
    }
  };

  const resetAll = () => {
    setPlayers([]);
    setScreen('home');
    setSelectedGame(null);
    setResult(null);
  };

  // --- Render Helpers ---

  const Header = ({ title, onBack }: { title: string; onBack?: () => void }) => (
    <div className="flex items-center justify-between p-6 bg-white/40 backdrop-blur-xl sticky top-0 z-10 border-b border-white/20">
      {onBack ? (
        <button onClick={onBack} className="p-3 rounded-2xl bg-white/50 hover:bg-white transition-colors shadow-sm">
          <ArrowLeft className="w-6 h-6 text-slate-600" />
        </button>
      ) : <div className="w-12" />}
      <h1 className="text-2xl font-display font-extrabold text-slate-800 tracking-tight">{title}</h1>
      <div className="w-12" />
    </div>
  );

  return (
    <div className="min-h-screen bg-brand-bg text-slate-900 font-sans selection:bg-indigo-100 overflow-x-hidden">
      <AnimatePresence mode="wait">
        
        {/* --- SCREEN: HOME --- */}
        {screen === 'home' && (
          <motion.div 
            key="home"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="flex flex-col items-center justify-center min-h-screen p-8 text-center"
          >
            <div className="relative mb-10">
              <motion.div 
                animate={{ 
                  rotate: [0, 5, -5, 0],
                  scale: [1, 1.05, 1]
                }}
                transition={{ repeat: Infinity, duration: 5 }}
                className="w-40 h-40 bg-brand-primary rounded-[48px] flex items-center justify-center shadow-2xl shadow-brand-primary/30"
              >
                <Zap className="w-20 h-20 text-white" />
              </motion.div>
              <motion.div 
                animate={{ y: [0, -10, 0] }}
                transition={{ repeat: Infinity, duration: 3 }}
                className="absolute -bottom-4 -right-4 w-16 h-16 bg-brand-accent rounded-[24px] border-4 border-brand-bg flex items-center justify-center shadow-lg"
              >
                <Users className="w-8 h-8 text-slate-800" />
              </motion.div>
            </div>
            
            <h1 className="text-5xl font-display font-black text-slate-900 mb-4 tracking-tighter">SorteaPlay</h1>
            <p className="text-slate-500 mb-14 max-w-[280px] leading-relaxed font-medium text-lg">
              Organiza tus juegos infantiles sin discusiones. ¡Rápido y divertido!
            </p>

            <motion.button 
              onClick={() => setScreen('players')}
              animate={{ 
                scale: [1, 1.03, 1],
                boxShadow: [
                  "0 20px 25px -5px rgba(67, 97, 238, 0.1), 0 10px 10px -5px rgba(67, 97, 238, 0.04)",
                  "0 25px 50px -12px rgba(67, 97, 238, 0.4), 0 15px 20px -5px rgba(67, 97, 238, 0.2)",
                  "0 20px 25px -5px rgba(67, 97, 238, 0.1), 0 10px 10px -5px rgba(67, 97, 238, 0.04)"
                ]
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 2.5,
                ease: "easeInOut"
              }}
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.95 }}
              className="pill-button group relative w-full max-w-xs bg-brand-primary text-white py-6 px-10 text-2xl shadow-2xl shadow-brand-primary/20 hover:bg-indigo-700 flex items-center justify-center gap-3"
            >
              Empezar a jugar
              <ChevronRight className="w-7 h-7 group-hover:translate-x-1 transition-transform" />
            </motion.button>
          </motion.div>
        )}

        {/* --- SCREEN: PLAYERS --- */}
        {screen === 'players' && (
          <motion.div 
            key="players"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="flex flex-col min-h-screen"
          >
            <Header title="¿Quién juega?" onBack={() => setScreen('home')} />
            
            <div className="p-6 flex-1 max-w-lg mx-auto w-full">
              <div className="flex gap-3 mb-10">
                <input 
                  type="text"
                  placeholder="Escribe un nombre..."
                  value={playerName}
                  onChange={(e) => setPlayerName(e.target.value)}
                  onKeyDown={(e) => e.key === 'Enter' && addPlayer()}
                  maxLength={12}
                  className="flex-1 bg-white border-2 border-slate-100 rounded-3xl px-6 py-5 focus:outline-none focus:border-brand-primary transition-all text-xl font-bold shadow-sm placeholder:text-slate-300"
                />
                <button 
                  onClick={addPlayer}
                  disabled={!playerName.trim() || players.length >= 10}
                  className="bg-brand-primary text-white p-5 rounded-3xl shadow-xl shadow-brand-primary/20 disabled:opacity-30 active:scale-90 transition-all"
                >
                  <Plus className="w-7 h-7" />
                </button>
              </div>

              <div className="space-y-4 mb-32">
                <div className="flex justify-between items-center px-4 mb-6">
                  <div className="flex flex-col">
                    <span className="text-xs font-black text-slate-400 uppercase tracking-[0.2em]">Participantes</span>
                    <span className="text-[10px] text-slate-300 font-bold">Toca el avatar para cambiarlo</span>
                  </div>
                  <span className="text-sm font-black text-brand-primary bg-brand-primary/10 px-4 py-1.5 rounded-full">
                    {players.length} / 10
                  </span>
                </div>
                
                {players.length === 0 ? (
                  <div className="text-center py-20 opacity-20">
                    <User className="w-20 h-20 mx-auto mb-4" />
                    <p className="text-xl font-bold">Añade los nombres de los niños</p>
                  </div>
                ) : (
                  players.map((p) => (
                    <motion.div 
                      initial={{ opacity: 0, y: 10 }}
                      animate={{ opacity: 1, y: 0 }}
                      key={p.id}
                      className="flex items-center justify-between bg-white p-5 rounded-[28px] border border-slate-100 shadow-sm hover:shadow-md transition-all"
                    >
                      <div className="flex items-center gap-5">
                        <button 
                          onClick={() => changeAvatar(p.id)}
                          className={cn("w-14 h-14 rounded-2xl flex items-center justify-center text-3xl shadow-inner active:scale-90 transition-transform", p.color)}
                        >
                          {p.avatar}
                        </button>
                        <span className="font-extrabold text-xl text-slate-700">{p.name}</span>
                      </div>
                      <button onClick={() => removePlayer(p.id)} className="p-3 text-slate-300 hover:text-red-500 transition-colors">
                        <Trash2 className="w-6 h-6" />
                      </button>
                    </motion.div>
                  ))
                )}
              </div>
            </div>

            <div className="fixed bottom-0 left-0 right-0 p-8 bg-gradient-to-t from-brand-bg via-brand-bg to-transparent">
              <button 
                disabled={players.length < 2}
                onClick={() => setScreen('games')}
                className="pill-button w-full max-w-lg mx-auto bg-brand-primary text-white py-6 text-2xl shadow-2xl shadow-brand-primary/20 disabled:opacity-30 disabled:shadow-none transition-all flex items-center justify-center gap-3"
              >
                Continuar
                <ChevronRight className="w-7 h-7" />
              </button>
            </div>
          </motion.div>
        )}

        {/* --- SCREEN: GAMES --- */}
        {screen === 'games' && (
          <motion.div 
            key="games"
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -50 }}
            className="flex flex-col min-h-screen"
          >
            <Header title="Elige un juego" onBack={() => setScreen('players')} />
            
            <div className="p-6 grid grid-cols-1 gap-5 max-w-lg mx-auto w-full pb-16">
              {GAMES.map((game, index) => (
                <motion.button 
                  key={game.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: index * 0.1 }}
                  whileHover={{ 
                    scale: 1.02, 
                    y: -5,
                    boxShadow: "0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04)"
                  }}
                  whileTap={{ scale: 0.95 }}
                  onClick={() => {
                    playPopSound();
                    setSelectedGame(game);
                    setScreen('instructions');
                  }}
                  className="group flex items-center gap-6 bg-white p-6 rounded-[40px] border border-slate-100 shadow-sm transition-all text-left"
                >
                  <motion.div 
                    whileHover={{ rotate: [0, -10, 10, 0] }}
                    className={cn("w-20 h-20 rounded-[28px] flex items-center justify-center text-white shadow-lg", game.color)}
                  >
                    {game.icon}
                  </motion.div>
                  <div className="flex-1">
                    <h3 className="text-2xl font-display font-black text-slate-800 mb-1">{game.name}</h3>
                    <p className="text-sm text-slate-500 font-medium line-clamp-2 leading-relaxed">{game.description}</p>
                  </div>
                  <motion.div 
                    whileHover={{ x: 5 }}
                    className="w-12 h-12 rounded-full bg-slate-50 flex items-center justify-center group-hover:bg-brand-primary group-hover:text-white transition-all"
                  >
                    <ChevronRight className="w-6 h-6" />
                  </motion.div>
                </motion.button>
              ))}
            </div>
          </motion.div>
        )}

        {/* --- SCREEN: INSTRUCTIONS --- */}
        {screen === 'instructions' && selectedGame && (
          <motion.div 
            key="instructions"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 1.05 }}
            className="flex flex-col min-h-screen"
          >
            <Header title={selectedGame.name} onBack={() => setScreen('games')} />
            
            <div className="p-8 flex-1 flex flex-col items-center justify-center max-w-lg mx-auto w-full text-center">
              <motion.div 
                animate={{ y: [0, -15, 0] }}
                transition={{ repeat: Infinity, duration: 4 }}
                className={cn("w-32 h-32 rounded-[40px] flex items-center justify-center text-white shadow-2xl mb-10", selectedGame.color)}
              >
                {selectedGame.icon}
              </motion.div>
              
              <div className="bg-white p-10 rounded-[48px] shadow-xl shadow-slate-200/50 border border-slate-100 mb-14 relative overflow-hidden">
                <div className="absolute top-0 left-0 w-full h-2 bg-brand-primary/20" />
                <div className="flex items-center justify-center gap-2 mb-6 text-brand-primary font-black uppercase tracking-[0.2em] text-xs">
                  <Info className="w-5 h-5" />
                  ¿Cómo se juega?
                </div>
                <p className="text-2xl text-slate-700 leading-relaxed font-bold italic">
                  "{selectedGame.description}"
                </p>
              </div>

              <div className="flex items-center gap-3 text-slate-400 mb-6 bg-white/50 px-6 py-3 rounded-full border border-white">
                <Users className="w-6 h-6" />
                <span className="font-black text-lg">{players.length} niños listos</span>
              </div>
            </div>

            <div className="p-8">
              <button 
                onClick={startDrawing}
                className="pill-button w-full max-w-lg mx-auto bg-brand-primary text-white py-7 text-3xl shadow-2xl shadow-brand-primary/30 active:scale-95 transition-all flex items-center justify-center gap-4"
              >
                ¡SORTEAR!
                <Play className="w-8 h-8 fill-current" />
              </button>
            </div>
          </motion.div>
        )}

        {/* --- SCREEN: DRAWING --- */}
        {screen === 'drawing' && (
          <motion.div 
            key="drawing"
            initial={{ opacity: 0 }}
            animate={{ 
              opacity: 1,
              backgroundColor: ['#5C59E8', '#FF7E5F', '#FFD166', '#10B981', '#5C59E8']
            }}
            transition={{ 
              backgroundColor: { repeat: Infinity, duration: 3, ease: "linear" }
            }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 flex flex-col items-center justify-center z-50 p-8 text-center overflow-hidden"
          >
            {/* Confetti Particles */}
            {[...Array(40)].map((_, i) => {
              const size = Math.random() * 12 + 6; // Random size between 6 and 18
              const isCircle = Math.random() > 0.5;
              const angle = Math.random() * Math.PI * 2;
              const distance = Math.random() * 400 + 100;
              const x = Math.cos(angle) * distance;
              const y = Math.sin(angle) * distance;

              return (
                <motion.div
                  key={i}
                  initial={{ 
                    x: 0, 
                    y: 0,
                    opacity: 0,
                    scale: 0,
                    rotate: 0
                  }}
                  animate={{ 
                    x: [0, x],
                    y: [0, y],
                    opacity: [0, 1, 1, 0],
                    scale: [0, 1.2, 1, 0],
                    rotate: [0, 360 * (Math.random() > 0.5 ? 1 : -1)]
                  }}
                  transition={{ 
                    repeat: Infinity, 
                    duration: 2 + Math.random(),
                    delay: Math.random() * 1.5,
                    ease: "easeOut"
                  }}
                  style={{ width: size, height: size }}
                  className={cn(
                    "absolute",
                    isCircle ? "rounded-full" : "rounded-sm",
                    PLAYER_COLORS[i % PLAYER_COLORS.length]
                  )}
                />
              );
            })}

            <motion.div
              animate={{ 
                rotate: [0, 360, 720],
                scale: [1, 1.4, 0.8, 1.2, 1],
                borderRadius: ["48px", "120px", "48px"]
              }}
              transition={{ 
                repeat: Infinity, 
                duration: 2,
                ease: "easeInOut"
              }}
              className="w-48 h-48 bg-white/20 backdrop-blur-2xl flex items-center justify-center mb-12 border-4 border-white/40 shadow-2xl"
            >
              <motion.div
                animate={{ 
                  scale: [1, 1.3, 1],
                  rotate: [0, -15, 15, 0]
                }}
                transition={{ repeat: Infinity, duration: 0.5 }}
              >
                <Zap className="w-24 h-24 text-white drop-shadow-lg" />
              </motion.div>
            </motion.div>
            
            <motion.div
              initial={{ y: 20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              className="relative z-10"
            >
              <motion.h2 
                animate={{ 
                  scale: [1, 1.1, 1],
                  color: ['#FFFFFF', '#FDE68A', '#FFFFFF']
                }}
                transition={{ repeat: Infinity, duration: 1 }}
                className="text-5xl font-display font-black text-white tracking-tighter"
              >
                ¡Sorteando Magia!
              </motion.h2>
              <p className="text-white/90 mt-6 font-black text-2xl tracking-tight">
                {selectedGame?.id === 'policias-ladrones' ? '¿Quién será el policía?' : 
                 selectedGame?.id === 'escondite' ? '¿Quién contará?' : 
                 '¡Preparando equipos!'}
              </p>
            </motion.div>
          </motion.div>
        )}

        {/* --- SCREEN: RESULT --- */}
        {screen === 'result' && result && selectedGame && (
          <motion.div 
            key="result"
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col min-h-screen"
          >
            <Header title="¡Resultado!" />
            
            <div className="p-8 flex-1 max-w-lg mx-auto w-full pb-40">
              <div className="text-center mb-12">
                <p className="text-slate-400 font-black uppercase tracking-[0.2em] text-xs mb-2">Juego</p>
                <h2 className="text-3xl font-display font-black text-slate-800">{selectedGame.name}</h2>
              </div>

              <div className="space-y-12">
                {result.assignments.map((group, gIdx) => (
                  <motion.div 
                    initial={{ opacity: 0, x: -20 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: gIdx * 0.2 }}
                    key={gIdx} 
                    className="space-y-5"
                  >
                    <div className="flex items-center gap-4 px-4">
                      <div className={cn("w-5 h-5 rounded-full shadow-lg", group.color || 'bg-slate-400')} />
                      <h3 className="font-display font-black text-2xl text-slate-800 tracking-tight">{group.label}</h3>
                      <span className="text-sm font-black text-slate-500 bg-white px-4 py-1.5 rounded-full border border-slate-100 shadow-sm">
                        {group.players.length}
                      </span>
                    </div>
                    
                    <div className="grid grid-cols-1 gap-3">
                      {group.players.map((p) => (
                        <div 
                          key={p.id}
                          className="flex items-center gap-5 bg-white p-5 rounded-[32px] border border-slate-100 shadow-sm"
                        >
                          <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center text-2xl shadow-inner", p.color)}>
                            {p.avatar}
                          </div>
                          <span className="font-extrabold text-xl text-slate-700">{p.name}</span>
                        </div>
                      ))}
                    </div>
                  </motion.div>
                ))}
              </div>
            </div>

            <div className="fixed bottom-0 left-0 right-0 p-8 bg-white/80 backdrop-blur-xl border-t border-slate-100 flex gap-4">
              <button 
                onClick={startDrawing}
                className="flex-1 bg-slate-100 text-slate-600 py-5 rounded-3xl font-black text-lg flex items-center justify-center gap-2 active:scale-95 transition-all"
              >
                <RotateCcw className="w-6 h-6" />
                Repetir
              </button>
              <button 
                onClick={resetAll}
                className="flex-[2] bg-brand-primary text-white py-5 rounded-3xl font-black text-xl shadow-2xl shadow-brand-primary/20 active:scale-95 transition-all flex items-center justify-center gap-2"
              >
                Nueva partida
              </button>
            </div>
          </motion.div>
        )}

      </AnimatePresence>
    </div>
  );
}
